# Greenhouse

[![Build](https://github.com/meteaurestudios/greenhouse/actions/workflows/build.yml/badge.svg)](https://github.com/meteaurestudios/greenhouse/actions/workflows/build.yml)

**Greenhouse** is an open-source Android host application for testing and playing **[Audio Plugins for Android (AAP)](https://github.com/atsushieno/aap-core)** in real time.

<p align="center">
  <img src="./docs/images/greenhouse.png" alt="Greenhouse Screenshot" width="360" />
</p>

---

## Features

- **Plugin Rack**: Play an instrument plugin and chain audio effects in real time.
- **Sandboxed & Crash-Safe**: Plugins run in isolated sandboxed processes, keeping the host alive and stable even if a plugin crashes.
- **Native Plugin GUIs**: Full touch interaction with native plugin interfaces, including zoom, pan, and fullscreen mode.
- **Parameter Controls & Presets**: Tweak sound parameters with dedicated knobs and sliders, or browse factory presets.
- **Hardware & On-Screen MIDI**: Connect USB or Bluetooth LE MIDI controllers, or play using the built-in multitouch keyboard.
- **MIDI Sequence Recorder**: Record what you play into a loop, layer takes, and play it back with a metronome, tap tempo, and quantize. Import and export `.mid` files.
- **Low Latency & Real-Time Meters**: Fast Oboe-powered audio engine with responsive VU level meters.
- **Plugin Browser**: Discover, search, and filter installed AAP plugins on your device.

---

## Installation

1. Go to the [**Releases**](https://github.com/meteaurestudios/greenhouse/releases) page.
2. Download the latest `greenhouse-*.apk`.
3. Install the APK on your Android device (Android 10+ / API 29+).
4. Launch the app and explore your installed AAP plugins!

---

## Roadmap

See [ROADMAP.md](ROADMAP.md) for architectural milestones, remaining tasks, and future feature enhancements.

---

## License

Greenhouse is licensed under the [Apache License 2.0](LICENSE). Copyright 2026 Meteaure Studios.

Third-party components keep their own licenses. See [NOTICE](NOTICE) for attributions.

The "Greenhouse" name and logo are not covered by this license and may not be used to endorse or promote derived products without permission.
