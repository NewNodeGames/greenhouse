# Greenhouse engine consumer R8 rules (applied to any app that depends on :greenhouse-engine)

# Preserve all native methods across the host application
-keepclasseswithmembernames class * {
    native <methods>;
}

# Preserve RackEngine and its companion object for JNI interop
-keep class org.androidaudioplugin.greenhouse.core.RackEngine { *; }
-keep class org.androidaudioplugin.greenhouse.core.RackEngine$* { *; }
-keep class org.androidaudioplugin.greenhouse.core.MidiSequencer { *; }
-keep class org.androidaudioplugin.greenhouse.core.MidiSequencer$* { *; }

# Preserve AAP Core Hosting and IPC structures
-keep class org.androidaudioplugin.** { *; }
-keep interface org.androidaudioplugin.** { *; }

# Preserve ktmidi UMP structures used in audio player
-keep class dev.atsushieno.ktmidi.** { *; }

# Preserve Oboe audio callback interfaces and helpers
-keep class com.google.oboe.** { *; }

# Keep attributes required for reflection, line numbers and annotations
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keepattributes SourceFile,LineNumberTable
