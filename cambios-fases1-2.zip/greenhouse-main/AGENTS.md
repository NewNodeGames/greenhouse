# Greenhouse Development Guide (`AGENTS.md`)

This repository is **`greenhouse`**, a modern Jetpack Compose Android host application for testing and playing **Audio Plugins for Android (AAP)**.

---

## 1. Project Architecture & Structure

The project is split into library modules so that downstream apps can build on the same base. Dependencies flow one way: `:app` → `:greenhouse-ui` → `:greenhouse-host` → `:greenhouse-engine` → aap-core. Kotlin packages are unchanged by the split.

- **`greenhouse-engine/`** (`:greenhouse-engine`): Audio engine, no UI.
  - **`src/main/cpp/`**: Native audio engine. Includes are relative to this folder (e.g. `"engine/OboeEngine.h"`).
    - `engine/OboeEngine`: reusable base that owns the AAudio output stream (open at the device's native rate, start / stop, reopen after errors, latency tuning, ADPF, denormals). Subclasses implement `prepareToPlay` / `streamStarting` / `process` / `flushState`.
    - `engine/TrackLayout.h`: how the rack's slots are laid out in tracks (`SLOTS_PER_TRACK` = instrument + `EFFECT_SLOTS_PER_TRACK` = 3 effects for now, up to `MAX_TRACKS`); slots are numbered across the rack, track by track. Shared with `RackEngine.kt`. The effect count is meant to change: nothing outside this file and its Kotlin twin may assume it, and sessions record the slots per track they were saved with (`RackPreset.slotsPerTrack`, `SlotPlacement.placeInTracks()`) so their slots return to the same position of the same track.
    - `RackEngine`: the rack built on `OboeEngine`: tracks side by side, each a serial chain (its instrument, then its effect slots) rendered in fixed-size blocks, then summed into the master with a per-track level, pan (equal power: the centre is unity and the far side fades out), mute and solo (the gain of each channel ramped per block; a muted track still runs so its notes end and plugins keep their state). Each slot runs a `SlotProcessor` and the rack keeps the rest: chains, bypass, NaN guard, meters (slots, tracks, master), CPU load, sequencer. Each slot also has a host level (gain) and dry / wet mix, ramped per block; the host resets them when a new plugin is added and saves them with the session.
    - `slot/SlotProcessor.h`: what runs in a slot (prepare, activate / deactivate, queued live UMP, `process()` over the previous slot's interleaved output). The rack owns it and destroys it once the audio thread has let go of it. `slot/AapSlotProcessor` wraps an AAP plugin instance (not owned; slots prepared at another sample rate stay silent until reloaded); DSP running inside the engine implements the same interface.
    - `sequencer/MidiSequencer`: MIDI sequencer owned by `RackEngine`. Records the notes played on the tracks' instruments and plays them back in a loop; an event's slot is its track index (`MAX_SEQUENCER_SLOTS` = `MAX_TRACKS`), sent to that track's instrument. A note-on may carry a chance (`getNoteProbability()` in `Sequence.h`: the third word of its packet, which MIDI 2.0 notes do not use, flagged so an empty word is 100%): `emitEvents()` rolls for it with `isNotePlayed()`, a hash of the seed (`setProbabilitySeed()`), the event's tick, slot and note, and the loop index counted from where playing started (not moved by `seek()`), so the same seed plays the same song and nothing is shared between threads; the note-off of a note that was not played is dropped by the existing tracking of notes started. `replaceEvents()` swaps the events without stopping the transport (editing while it plays), and `startPlayback(fromTick)` / `seek()` move the playhead; the arrangement is flattened into events by the host. It plays the events in a loop (PPQ 960 ticks, 4/4 bars), handing each slot processor sample-accurate JR-timestamped UMP for its block (`AapSlotProcessor` writes it into the plugin's MIDI2 input port, where aap-core merges the queued live input). The audio thread reads an immutable `PlaybackBuffer` swapped through an atomic pointer (old buffers freed once `OboeEngine::hasAudioThreadPassed()`), and takes transport commands from a lock-free queue. Also the metronome (`sequencer/Metronome`) and `.mid` import / export (`sequencer/StandardMidiFile`).
    - `RackEngineJni.cpp` / `MidiSequencerJni.cpp`: JNI bindings to a single process-wide `RackEngine` (`getEngine()`, defined in `EngineApi.cpp`; no native handles cross JNI).
    - `EngineApi.h`: the native API other modules' C++ code can call (`setSlotProcessor()` on the app's rack, e.g. to run their own DSP in a slot). It is published with `slot/SlotProcessor.h`, `slot/SlotEvents.h` (reading the events a processor receives: JR timestamps, AAP parameter changes) and `sequencer/Ump.h` as the module's prefab package (`find_package(greenhouse-engine REQUIRED CONFIG)`, target `greenhouse-engine::greenhouse-engine`). The library hides every other symbol: mark new entry points `GREENHOUSE_API` and keep the published headers free of Oboe, AAP and engine internals.
    - `utils/AudioSimd.h`: NEON helpers. `utils/Logging.h`: log macros.
  - **`greenhouse/core/AapHostEngine.kt`**: Connects to AAP services and instantiates `NativeRemotePluginInstance`.
  - **`greenhouse/core/RackEngine.kt`**: Kotlin side of the native `RackEngine`: tracks (`numTracks`, slot helpers `instrumentSlotOf()` / `effectSlotOf()`, per-track level, pan, mute, solo and meters), transport, AAP slot plugins (`clearSlot()` empties a slot whatever it holds), meters, and MIDI UMP parameter / note dispatching. The sequencer records only the notes sent to the instrument slots.
  - **`greenhouse/core/MidiSequencer.kt`**: Kotlin side of the native sequencer (`RackEngine.sequencer`): settings, transport, status, packed events.
  - **`greenhouse/core/MidiControllerManager.kt`**: Hardware MIDI input and MIDI 1.0 → UMP stream parser.
  - Manifest declares audio permissions and the AAP service `<queries>`; `consumer-rules.pro` carries the JNI / AAP R8 keep rules.
- **`greenhouse-host/`** (`:greenhouse-host`): Host state and logic, no screens.
  - **`greenhouse/device/`**: What fills a slot. `SlotDevice` (parameters, presets, state, attaching its processor to the native rack) and `SlotDeviceSource` (lists `DeviceInfo`s, tells when that list may have changed, and creates devices; its `id` is saved as each slot's `source` in `.ghrack`).
    - `aap/`: the AAP implementation. `AapDeviceSource` (installed plugins, one `AapHostEngine` slot host each, package changes through aap-core's `InstalledPluginsMonitor`), `AapSlotDevice` (a `NativeRemotePluginInstance`, process death detection, parameter list kept current through aap-core's `addParameterMetadataChangedListener`), `PluginSlotLoader` (blocking instance queries: instantiate, dynamic parameter / port discovery, value and preset-name reads; IO thread only, except `queryUnlessDied`).
  - **`greenhouse/device/ParameterRandomizer.kt`** and **`greenhouse/ui/model/ParameterType.kt`**: random values for the parameters of a plugin, by what each one is (`inferredType`: continuous, whole number, option of a list, switch). At 100% a value falls anywhere in its range, below that within that share of the range around the current value; a positive range 100 times wider (a filter cutoff) is spread by octaves. Parameters whose name has `master`, `output`, `volume`, `bypass`, `mute`, `solo`, `power`, `enable`, `active` or `on/off` are left alone. `ParameterType.kt` lives in the host module, in the package `greenhouse.ui.model` it always had, so the randomizer can use it and it can be tested without the UI module (an empty file is left at its old place in the UI module: the zip deliveries only overwrite, and the same class in two modules would not build; delete it freely).
  - **`greenhouse/data/`**: `PluginRepository` (discovers AAP services via `AudioPluginHostHelper`), `.ghrack` session models, serializer, and storage. `SlotPlacement` restores saved slots by role (`SlotType`) and order rather than index, so sessions survive rack layout changes.
  - **`greenhouse/project/`**: the arrangement, plain Kotlin with no Android dependency (unit-testable on the JVM). A `Project` is `Track`s (track n is rack track n), each with `Clip`s (sequences of `ClipNote`s, whole bars long) and non-overlapping `Placement`s of them along the song's bars; a clip placed twice is one clip, so editing it changes every placement. All of it is immutable: `ProjectEditing.kt` (tracks, clips, placements) and `ClipEditing` (notes, as the piano roll edits them) return the changed value. `ArrangementFlattener` turns the project into the packed events the engine's sequencer plays (flattened events have take 0, so a later recording is told apart by its take); the host swaps them in with `MidiSequencer.replaceEvents()`. `ClipNoteCodec` packs a clip's notes for the session file; the chance of a note rides in the upper half of its velocity int, as the percent it is *not* played, so notes saved before it existed always play. `ClipNote.probability` is one of `ClipNote.PROBABILITY_LEVELS` and `Project.probabilitySeed` seeds the rolls: the flattener puts a chance below 100% in the third word of the note-on (flagged; see below), and the engine rolls for it as it plays. `sanitized()` makes a project read from a file consistent. `.ghrack` schema 2 saves the project under `project`; `sequence` then only holds the sequencer settings. Sessions saved before it (schema 1, a single looping sequence) become a project with `RackPreset.resolveProject()` (`LegacySequenceImport`): one clip per track that had notes, placed at bar 1.
  - **`greenhouse/ui/HostViewModel.kt`**: Thin composition root. Wires the controllers below, runs the engine monitor loop, and handles app lifecycle. Screens access controllers directly (`viewModel.rack`, `viewModel.audio`, …).
  - **`greenhouse/ui/HostConfig.kt`**: How an app configures the host (its device sources, AAP only by default), given through `HostViewModel.factory(config)`.
  - **`greenhouse/ui/RackModels.kt`**: Rack UI models (`RackSlotData`, `SlotUiState`, `StudioRackViewMode`, …).
  - **`greenhouse/ui/host/`**: Feature controllers owned by `HostViewModel`:
    - `RackController`: the engine's rack (it also randomizes the parameters of a slot's plugin, `randomizeParameters()`, with one step of undo kept in `SlotUiState.randomizeUndo`; the choice of values is the pure `ParameterRandomizer`), `numSlots` slots (`numTracks` x `SLOTS_PER_TRACK`: each track has its instrument, then its effect slots; the host has `RackEngine.DEFAULT_NUM_TRACKS` = 4 tracks). `selectActiveSlot()` also points the engine's note target (`RackEngine.setNoteTarget()`) at the instrument of the slot's track, so what is played on the keyboard or a MIDI controller, and recorded, goes to the track being edited; anything that tells an instrument slot from an effect one uses `RackEngine.isInstrumentSlot()`, never an index, device load / unload / restore through the sources, bypass, parameters, presets, device-side parameter sync and parameter list changes (`SlotDevice.onParametersChanged`), crashed devices. A slot restored with a saved state gets that state alone (it holds the preset and parameter values, and the saved ones may be stale: aap-core does not always learn of changes made inside a plugin); without one, the saved preset is selected and the saved parameter values are pushed.
    - `AudioEngineController`: `RackEngine` transport, buffer sizing, background / foreground pause and resume.
    - `RackMeters`: per-slot levels and CPU load.
    - `PluginBrowserController`: device catalog from every source (listed again when a source reports a change), slot-target filtering, developer filter, search, saved device lookup.
    - `VirtualKeyboardController` / `MidiDeviceController`: on-screen keyboard state and hardware MIDI input.
    - `RackSessionController`: saved sessions, autosave, session restore (including the sequence and the arrangement, whose revision counts for the session's unsaved changes).
    - `SequencerController`: sequencer transport, settings, note lane, tap tempo, `.mid` import / export, sequence capture / restore. It plays the arrangement's song: stopping a recording, importing a `.mid`, clearing and undoing go through the `ProjectController`, and the loop length follows the song once it has clips. `startTick` is the cursor playing starts from (`seekTo()` moves it, and the playhead too while playing).
    - `ProjectController`: the `Project` (Compose state), its undo / redo history and what makes the engine play it. After each change it flattens the project and sends the events with `replaceEvents()` (only when they changed: sending them ends the notes sounding, so a track's level alone does not), sets the song length on the sequencer once the song has clips (an empty song leaves it to the sequencer's setting, which can be automatic so the first take sets it), and sets each track's level, pan, mute and solo on the engine. `commitRecording()` turns the takes the engine recorded into clips (`RecordingImport`) when a recording ends; it is idempotent, and `SequencerController` calls it on stop and when polling sees the recording end. Track level, pan, mute and solo (`updateTrackMix()`) are not steps of the undo history and survive undo / redo (`withMixOf()`); the project is always padded to the rack's tracks (`withTrackCount()`). Main thread only.
  - Manifest declares the session-sharing `FileProvider` (`${applicationId}.fileprovider`).
- **`greenhouse-ui/`** (`:greenhouse-ui`): Compose UI.
  - **`greenhouse/ui/MainHostApp.kt`**: Root composable and navigation graph.
  - **`greenhouse/ui/screens/StudioRackScreen.kt`**: Studio rack UI (track strip, then the signal chain of the active track, slot cards, parameter controls, native plugin surfaces).
  - **`greenhouse/ui/screens/ArrangementScreen.kt`**: the song as a timeline, reached from the rack's banner: a lane per rack track with its clips placed along the bars (a clip shows its name and a preview of its notes), the playhead, the cursor, and a panel under it for the selection: an empty bar (add a new clip of 1 / 2 / 4 bars, or place one the track already has) or a placed clip (copy, cut and paste it, *Repeat* it once or four or eight times, make its clip shorter or longer, remove the placement or delete the clip). *Repeat* places more instances of the *same* clip right after (linked: editing the clip changes them all) and selects the last one made, so pressing again goes on from it; *Copy* / *Cut* / *Paste* go through `ProjectController.clipboard` (a `ClipContent`: name, length and notes) and a paste makes a new, independent clip, in any track, at the selected empty bar or after the selected clip. Every change goes through `ProjectController.edit()`, which refuses what does not fit (overlaps) and the screen says so through `report()`. Tapping the ruler moves the cursor (`SequencerController.seekTo()`), tapping a track's number makes it the track played and recorded on. Zoom has six bar widths (the offset is scaled so the left edge stays about where it was, after waiting a frame or two for the new width to be measured), and *Follow* pages the timeline when the playhead leaves the view or loops back, except while a finger is scrolling it. A clip is moved by pressing it and holding, then dragging (the same gesture as the piano roll's notes): a ghost shows the bar and track it is over, orange if it does not fit, and dropping it is one undo step (`movePlacementToTrack()`: into another track the clip goes as a copy, since a track's clips belong to it and play on its instrument).
  - **`greenhouse/ui/screens/PianoRollScreen.kt`**: the notes of one clip (route `pianoroll/{track}/{clip}`, opened with *Edit notes* on a placed clip in the arrangement): a grid of time across (1/1, 1/2, 1/4, 1/8, 1/16, 1/32 and the triplets 1/4T, 1/8T, 1/16T; three zoom levels) and pitch down, a keyboard that sounds when tapped, the bar ruler, and the playhead while the song plays. Tap an empty place to add a note as long as the grid, a note to select it (in *Multi* mode, the default, tapping adds the note to the selection and takes it out if it was in; in *Single* mode the notes selected before are let go, and tapping the only one selected puts it away); press a note and hold, then drag, to move the selection (shown while moving, one undo step when released); a button in the header puts the whole panel of buttons under the grid away (it takes room the grid can use); buttons delete, copy, quantize, transpose, nudge by the grid, lengthen, shorten and set the velocity of the selection to soft (50%) or loud (100%). Under the grid a velocity lane has a bar per note (the bars of a chord are spread out): tap or drag one to set the velocity of that note alone (one undo step per drag). A note's chance of being played is one of five levels (0, 25, 50, 75, 100%) set on the selection, shown on the note (a bar for its chance, faint when 0%), and the *Seed* control changes the project's `probabilitySeed`. Everything goes through `ProjectController.edit()` with the pure `ClipEditing` functions, so each change is an undo step and is heard at once if the song plays. The gestures read what changes through `rememberUpdatedState` and are not keyed: restarting them would cancel a drag in progress. Auditioning uses `engine.sendNoteOn()`, which plays the active track, so the screen selects its track on opening.
  - **`greenhouse/ui/screens/rack/RackTrackStrip.kt`**: one card per rack track: select it, mute, solo, level and pan faders. Mix changes go through `ProjectController.updateTrackMix()`.
  - **`greenhouse/ui/screens/rack/RackSequencer.kt`**: Sequencer strip in the keyboard card (record, play / stop, read-only lane, tempo / length chip) and its settings sheet.
  - **`greenhouse/ui/screens/PluginBrowserScreen.kt`**: Plugin catalog browser with category filters and search.
  - **`greenhouse/ui/screens/EngineSettingsScreen.kt`**: Audio hardware specs and diagnostic monitor.
  - **`greenhouse/ui/theme/`**, **`greenhouse/ui/components/`**: Theme and reusable controls.
- **`app/`** (`:app`): Thin application shell (`org.androidaudioplugin.greenhouse`): `MainActivity`, launcher icons, app name, signing, and release config. Keep app logic out of this module.
- **`external/aap-core/`**: Submodule containing core AAP runtime (`:androidaudioplugin`) and Compose UI interop (`:androidaudioplugin-ui-compose`).

> **CRITICAL RULE: Submodule Immutability**  
> Any repository or file located under `external/` (including `external/aap-core`) **MUST NOT BE ALTERED OR EDITED**. All application code, workarounds, UI fixes, and engine wrappers must be implemented strictly inside the main project files (e.g. `app/`).

---

## 2. Build & Execution Commands

Always specify `JAVA_HOME` using Android Studio's bundled JDK when invoking Gradle:

```bash
JAVA_HOME="/Applications/Android Studio.app/Contents/jbr/Contents/Home" ./gradlew assembleDebug
```

The native MIDI sequencer and rack have desktop tests (no Android needed), with stubs for the Oboe engine and logging and fake slot processors:

```bash
cmake -S greenhouse-engine/src/test/cpp -B build/engine-test && cmake --build build/engine-test && build/engine-test/MidiSequencerTest && build/engine-test/RackEngineTest
```

> **Note**: Gradle requires network loopback socket permissions for its daemon process. When running Gradle in sandbox environments, run with unsandboxed execution (`BypassSandbox: true`).

---

## 3. Crucial AAP Architecture Rules

### Parameter & Port Discovery
1. **Static Manifest (`aap_metadata.xml`)**:
   - `AudioPluginHostHelper` populates `PluginInformation.parameters` **only** if the plugin statically declared `<parameter>` XML elements in `aap_metadata.xml`.
2. **Dynamic AAPXS Extension**:
   - Most AAP plugins expose parameters dynamically at runtime over the `parameters` AAPXS extension.
   - When instantiating a plugin (`NativeRemotePluginInstance`), if `plugin.parameters.isEmpty()`, query `instance.getParameterCount()` and `instance.getParameter(i)` to dynamically discover parameters. Do the same for `plugin.ports` via `instance.getPortCount()` and `instance.getPort(i)`.

### Realtime Audio Thread Safety
1. **Lock-Free Audio Callbacks**:
   - The Oboe / AAudio audio render callback (`onAudioReady`) runs at highest realtime priority (`SCHED_FIFO`).
   - **NEVER** use mutexes (`std::mutex`, `std::unique_lock`, `try_lock`), priority-inversion hazards, system calls, or dynamic heap allocations (`malloc`, `free`, `new`, `delete`) inside the audio callback or realtime render path.
   - All state accessed in the audio thread MUST use lock-free atomics (e.g. `std::atomic<aap::PluginInstance*>`, atomic port indices, and atomic render epoch counters for control-thread quiescent-state synchronization).

### Jetpack Compose UI Patterns
1. **Grid Item Keying**:
   - In `LazyVerticalGrid` / `LazyColumn` for parameter controls, always scope item keys to include the slot index and plugin ID:
     `key = { param -> "${slotIndex}_${pluginId}_${param.id}" }`
   - Never use raw `param.id` alone as a key, because numeric IDs collide across different plugins when switching slots.
2. **Touch Targets & Sizing**:
   - Standard Material 3 `IconButton` enforces a minimum 48dp interactive component size layout. When precise custom dimensions are needed without forced padding, use `Box(modifier = Modifier.size(...).clip(CircleShape).clickable { ... })`.
3. **Window Insets**:
   - Account for system navigation bar insets using `WindowInsets.navigationBars` or `WindowInsets.systemBars`.
4. **Panels & Controls**:
   - Use the shared style in `greenhouse-ui/.../ui/components/ControlSurface.kt`: `Modifier.panelSurface()` for a rack panel (bordered card), `Modifier.controlSurface()` / `ControlButton` for the controls inside it (`CONTROL_HEIGHT`, `CONTROL_SHAPE`).
   - Controls inside a panel are filled, without an outline; while on, they take a tint of their accent (`isActive`). Do not nest outlined boxes inside outlined panels.
   - Labels and buttons use sentence case ("Play", "Hold", "Load"), never all caps with letter spacing. The monospace, uppercase style is kept for the slot badges and diagnostic text.
5. **Icon + Text Buttons**:
   - In any button or control combining an icon and text, the icon and text form one group, centered inside the container (`Box(contentAlignment = Alignment.Center)` around the group, or `horizontalArrangement = Arrangement.spacedBy(spacing, Alignment.CenterHorizontally)`). Never push them apart with `Arrangement.SpaceBetween` or a weighted spacer, and never leave the group start-aligned in a wider container.

---

## 4. Code Formatting & Style Rules

1. **Mandatory Braces and Newlines**:
   - All `if`, `else if`, `else`, `for`, and `while` control flow statements (in both Kotlin and C/C++) **MUST ALWAYS** have curly brackets `{}` with their body on a new line. Single-line statement bodies without braces are strictly prohibited.
2. **Blank Lines Around Control Flow Blocks**:
   - All `if`, `else if`, `else`, `for`, and `while` blocks **MUST ALWAYS** have a blank / new line immediately before and after them (to clearly separate control flow blocks from preceding and subsequent statements).
3. **`auto` with `static_cast` (C++)**:
   - Always use `auto` when declaring and assigning a variable initialized with a `static_cast` (e.g. `auto out = static_cast<float*>(...);` rather than `float* out = static_cast<float*>(...);`).
4. **C++ Function Opening Braces on New Line**:
   - All C++ functions (constructors, destructors, member methods, and JNI functions) **MUST ALWAYS** place their opening curly bracket `{` on a new line.
5. **C++ Member Variable Naming (`m` Prefix & CamelCase)**:
   - All C++ member variables (in classes and structs) **MUST ALWAYS** start with a lowercase `m` followed by CamelCase (e.g. `mSampleRate`, `mFramesPerCallback`, `mIsProcessing`, `mSlots`, `mAudioInPorts`, `mCpuLoad`).
6. **No Magic / Hardcoded Numbers**:
   - Never use raw numeric literals or magic values (e.g. `256`, `512`, `16384`, `4096`, `128`, `44100`, etc.) directly in business logic, fallbacks, or buffer calculations.
   - Always define named, self-documenting constants (`constexpr`, `const val`, or `companion object` constants) such as `DEFAULT_FRAMES_PER_CALLBACK`, `DEFAULT_BURST_MULTIPLIER`, `FIFO_CAPACITY_FRAMES`, `MAX_DSP_BLOCK_FRAMES`, `DEFAULT_SAMPLE_RATE`, etc., with clear semantic meaning.

## Native ABIs

Native code is built for, and the app packages libraries of, the ABIs listed in `greenhouse.abis` in `gradle.properties` (64-bit ARM, `arm64-v8a`, only for now). The root `build.gradle.kts` applies it to every Android module through `ndk.abiFilters`, the external aap-core ones included, so a new module needs no setting of its own. To build for more (`armeabi-v7a`, `x86`, `x86_64`), change that one property or pass `-Pgreenhouse.abis=...`. The desktop tests of the engine (`greenhouse-engine/src/test/cpp`) do not depend on it.
