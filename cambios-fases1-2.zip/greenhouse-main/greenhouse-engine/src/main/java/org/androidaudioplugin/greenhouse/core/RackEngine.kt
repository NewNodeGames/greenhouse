package org.androidaudioplugin.greenhouse.core

import android.content.Context
import android.util.Log
import org.androidaudioplugin.ParameterInformation
import org.androidaudioplugin.hosting.NativeRemotePluginInstance
import org.androidaudioplugin.hosting.UmpHelper
import dev.atsushieno.ktmidi.Ump
import dev.atsushieno.ktmidi.UmpFactory
import dev.atsushieno.ktmidi.toPlatformNativeBytes
import java.nio.ByteOrder

/** How the output stream was actually opened, which can be less than the low-latency exclusive MMAP stream requested. */
data class OutputStreamMode(
    val isLowLatency: Boolean,
    val isExclusive: Boolean,
    /** MMAP is the fastest path; without it the stream goes through the legacy path, with larger bursts. */
    val isMMapUsed: Boolean
)

/**
 * Kotlin side of the native `RackEngine` (one per process). Only one instance should be alive at a
 * time: creating one reconfigures the native engine, and closing it releases the audio device.
 *
 * The rack has [numTracks] tracks side by side, summed into the master. A track is a serial chain: its
 * instrument in the first of its [SLOTS_PER_TRACK] slots, then [EFFECT_SLOTS_PER_TRACK] effect slots.
 * Slots are numbered across the rack, track by track: `slot = track * SLOTS_PER_TRACK + position`.
 */
class RackEngine(
    framesPerCallback: Int,
    val numTracks: Int = DEFAULT_NUM_TRACKS
) : AutoCloseable {

    companion object {
        private const val TAG = "RackEngine"

        // Layout shared with engine/TrackLayout.h
        const val EFFECT_SLOTS_PER_TRACK = 4
        const val INSTRUMENT_SLOT_IN_TRACK = 0
        const val SLOTS_PER_TRACK = INSTRUMENT_SLOT_IN_TRACK + 1 + EFFECT_SLOTS_PER_TRACK
        const val MAX_TRACKS = 8
        const val DEFAULT_NUM_TRACKS = 1
        private const val STEREO_CHANNELS = 2
        const val DEFAULT_NUM_RACK_SLOTS = DEFAULT_NUM_TRACKS * SLOTS_PER_TRACK

        /** Whether the slot is the instrument of its track (otherwise it is one of its effects). */
        fun isInstrumentSlot(slotIndex: Int): Boolean {
            return slotIndex % SLOTS_PER_TRACK == INSTRUMENT_SLOT_IN_TRACK
        }

        /** The slot of the track's instrument. */
        fun instrumentSlotOf(trackIndex: Int): Int {
            return trackIndex * SLOTS_PER_TRACK + INSTRUMENT_SLOT_IN_TRACK
        }

        /** The slot of the track's [effectIndex]th effect, from 0. */
        fun effectSlotOf(trackIndex: Int, effectIndex: Int): Int {
            return trackIndex * SLOTS_PER_TRACK + INSTRUMENT_SLOT_IN_TRACK + 1 + effectIndex
        }

        /** The track a slot belongs to. */
        fun trackOfSlot(slotIndex: Int): Int {
            return slotIndex / SLOTS_PER_TRACK
        }
        const val MIDI2_SIGNED_32BIT_MAX = 0x8000_0000L
        const val MIDI2_32BIT_MAX = 0xFFFF_FFFFL
        const val MIDI2_16BIT_MAX = 0xFFFF
        const val MIDI_CC_ALL_SOUND_OFF = 120
        const val MIDI_CC_ALL_NOTES_OFF = 123
        // 32-bit words in a 128-bit UMP packet (SysEx8 parameter changes)
        const val UMP128_WORD_COUNT = 4
        // aap-core queues a fixed number of inputs per slot until the next process() and drops the rest,
        // so many values are sent in as few inputs as possible, leaving half the merge room to the sequencer
        const val UMP_INPUT_SHARE_OF_EVENT_BUFFER = 2

        /**
         * aap-core's event buffer (DEFAULT_EVENT_MIDI2_INPUT_BUFFER_SIZE): the most bytes of one queued
         * UMP input, and of a block's queued input merged with the sequencer's events.
         */
        val aapEventBufferBytes: Int by lazy { nativeGetAapEventBufferBytes() }

        val maxUmpInputBytes: Int
            get() = aapEventBufferBytes / UMP_INPUT_SHARE_OF_EVENT_BUFFER

        init {
            try {
                System.loadLibrary("greenhouse-engine")
                Log.d(TAG, "Loaded greenhouse-engine library")
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to load greenhouse-engine library", e)
            }
        }

        @JvmStatic
        private external fun nativeConfigure(framesPerCallback: Int, numTracks: Int)

        @JvmStatic
        private external fun nativeShutdown()

        @JvmStatic
        private external fun nativeStart(): Boolean

        @JvmStatic
        private external fun nativePause()

        @JvmStatic
        private external fun nativeOpenStream(): Boolean

        @JvmStatic
        private external fun nativeCloseStream()

        @JvmStatic
        private external fun nativeIsStreaming(): Boolean

        @JvmStatic
        private external fun nativeSetFramesPerCallback(framesPerCallback: Int)

        @JvmStatic
        private external fun nativeGetSampleRate(): Int

        @JvmStatic
        private external fun nativeGetBurstFrames(): Int

        @JvmStatic
        private external fun nativeIsLowLatency(): Boolean

        @JvmStatic
        private external fun nativeIsExclusive(): Boolean

        @JvmStatic
        private external fun nativeIsMMapUsed(): Boolean

        @JvmStatic
        private external fun nativeSetSlotPlugin(slotIndex: Int, nativeClient: Long, instanceId: Int, sampleRate: Int)

        @JvmStatic
        private external fun nativeSetSlotBypassed(slotIndex: Int, bypassed: Boolean)

        @JvmStatic
        private external fun nativeSetSlotGain(slotIndex: Int, gain: Float)

        @JvmStatic
        private external fun nativeSetSlotMix(slotIndex: Int, mix: Float)

        @JvmStatic
        private external fun nativeSetTrackGain(trackIndex: Int, gain: Float)

        @JvmStatic
        private external fun nativeSetTrackMuted(trackIndex: Int, muted: Boolean)

        @JvmStatic
        private external fun nativeSetTrackSoloed(trackIndex: Int, soloed: Boolean)

        @JvmStatic
        private external fun nativeSendUmp(slotIndex: Int, data: ByteArray, length: Int)

        @JvmStatic
        private external fun nativeGetCpuLoad(): Float

        @JvmStatic
        private external fun nativeGetSlotCpuLoad(slotIndex: Int): Float

        @JvmStatic
        private external fun nativeGetSlotInvalidBlocks(slotIndex: Int): Int

        @JvmStatic
        private external fun nativeGetAllSlotLevels(outLevels: FloatArray)

        @JvmStatic
        private external fun nativeGetTrackLevels(outLevels: FloatArray)

        @JvmStatic
        private external fun nativeGetMasterLevels(outLevels: FloatArray)

        @JvmStatic
        private external fun nativeGetAapEventBufferBytes(): Int
    }

    /**
     * Native sample rate of the output device, 0 if no stream could be opened yet. It can change
     * after a device change (e.g. Bluetooth headphones): plugins must then be re-prepared at it.
     */
    val sampleRate: Int
        get() = nativeGetSampleRate()

    val actualBurstSize: Int
        get() = nativeGetBurstFrames().coerceAtLeast(0)

    /** Mode of the last opened output stream. It can change when the stream is reopened after a device change. */
    val streamMode: OutputStreamMode
        get() = OutputStreamMode(nativeIsLowLatency(), nativeIsExclusive(), nativeIsMMapUsed())

    /** Every slot of the rack. */
    val numSlots: Int = numTracks.coerceIn(1, MAX_TRACKS) * SLOTS_PER_TRACK

    init {
        nativeConfigure(framesPerCallback, numTracks)
    }

    /** Records the MIDI sent to the slots and plays it back. Its transport runs while the engine does. */
    val sequencer = MidiSequencer()

    /** Frames each plugin renders per block, independent of the device burst size. */
    fun setFramesPerCallback(frames: Int) {
        nativeSetFramesPerCallback(frames)
    }

    /** Whether audio is running. Turns false on its own if the stream cannot be restarted after a device error. */
    val isProcessing: Boolean
        get() = nativeIsStreaming()

    val totalCpuLoad: Float
        get() = nativeGetCpuLoad()

    fun getSlotCpuLoad(slotIndex: Int): Float {
        if (slotIndex in 0 until numSlots) {
            return nativeGetSlotCpuLoad(slotIndex)
        }

        return 0f
    }

    /** Output blocks the engine dropped because they held NaN or infinite samples, since the slot's plugin was set. */
    fun getSlotInvalidBlocks(slotIndex: Int): Int {
        if (slotIndex in 0 until numSlots) {
            return nativeGetSlotInvalidBlocks(slotIndex)
        }

        return 0
    }

    fun getAllSlotLevels(outLevels: FloatArray) {
        if (outLevels.isNotEmpty()) {
            nativeGetAllSlotLevels(outLevels)
        }
    }

    /** Fills [outLevels] with the (left, right) peak of each track in the mix, after its level, mute and solo. */
    fun getTrackLevels(outLevels: FloatArray) {
        if (outLevels.isNotEmpty()) {
            nativeGetTrackLevels(outLevels)
        }
    }

    /** Fills [outLevels] (at least two values) with the (left, right) peak of the master. */
    fun getMasterLevels(outLevels: FloatArray) {
        if (outLevels.size >= STEREO_CHANNELS) {
            nativeGetMasterLevels(outLevels)
        }
    }

    /** Level of the track in the master mix, as a linear gain. */
    fun setTrackGain(trackIndex: Int, gain: Float) {
        if (trackIndex in 0 until numTracks) {
            nativeSetTrackGain(trackIndex, gain)
        }
    }

    /** A muted track still runs, so its plugins keep their state, but is not heard. */
    fun setTrackMuted(trackIndex: Int, muted: Boolean) {
        if (trackIndex in 0 until numTracks) {
            nativeSetTrackMuted(trackIndex, muted)
        }
    }

    /** While any track is soloed, only the soloed tracks are heard. */
    fun setTrackSoloed(trackIndex: Int, soloed: Boolean) {
        if (trackIndex in 0 until numTracks) {
            nativeSetTrackSoloed(trackIndex, soloed)
        }
    }

    /**
     * Puts [instance] in the slot; the engine activates it if it is playing and resets the slot's bypass.
     * [sampleRate] is the rate [instance] was prepared at: the slot stays silent while it differs from
     * the engine's [sampleRate]. Returns once the audio thread has let go of the previous instance.
     */
    fun setSlotPlugin(slotIndex: Int, instance: NativeRemotePluginInstance, sampleRate: Int) {
        if (slotIndex in 0 until numSlots) {
            nativeSetSlotPlugin(slotIndex, instance.client, instance.instanceId, sampleRate)
        }
    }

    /**
     * Empties the slot, whatever processor it holds (an AAP plugin or one installed natively). Returns
     * once the audio thread has let go of it, so it can be destroyed.
     */
    fun clearSlot(slotIndex: Int) {
        if (slotIndex in 0 until numSlots) {
            nativeSetSlotPlugin(slotIndex, 0L, -1, 0)
        }
    }

    fun setSlotBypassed(slotIndex: Int, bypassed: Boolean) {
        if (slotIndex in 0 until numSlots) {
            nativeSetSlotBypassed(slotIndex, bypassed)
        }
    }

    /** Linear gain the host applies to the slot's output. [setSlotPlugin] leaves it unchanged. */
    fun setSlotGain(slotIndex: Int, gain: Float) {
        if (slotIndex in 0 until numSlots) {
            nativeSetSlotGain(slotIndex, gain)
        }
    }

    /** Dry / wet balance the host applies to the slot (0: input only, 1: plugin output only). [setSlotPlugin] leaves it unchanged. */
    fun setSlotMix(slotIndex: Int, mix: Float) {
        if (slotIndex in 0 until numSlots) {
            nativeSetSlotMix(slotIndex, mix)
        }
    }

    fun start() {
        if (isProcessing) {
            return
        }

        if (nativeStart()) {
            Log.d(TAG, "Rack engine started")
        } else {
            Log.e(TAG, "Failed to start rack engine")
        }
    }

    /** Opens the output stream without starting it, so [sampleRate] is current. Returns false if the device could not be opened. */
    fun openStream(): Boolean {
        return nativeOpenStream()
    }

    /**
     * Stops audio and releases the audio device, keeping the slots. [start] opens a new stream.
     * Restarting a fresh stream avoids resuming one that AAudio put in standby, which can crash in AAudio.
     */
    fun closeStream() {
        if (isProcessing) {
            allNotesOff()
        }

        nativeCloseStream()
        Log.d(TAG, "Output stream closed")
    }

    /** To every slot: empty ones drop it. */
    fun allNotesOff() {
        for (slotIndex in 0 until numSlots) {
            sendControlChange(slotIndex, MIDI_CC_ALL_SOUND_OFF, 0.0f)
            sendControlChange(slotIndex, MIDI_CC_ALL_NOTES_OFF, 0.0f)
        }
    }

    fun pause() {
        if (!isProcessing) {
            return
        }

        allNotesOff()
        nativePause()
        Log.d(TAG, "Rack engine paused")
    }

    fun sendNoteOn(note: Int, velocity: Float = 1.0f) {
        val velocity16 = (velocity.coerceIn(0.0f, 1.0f) * MIDI2_16BIT_MAX).toInt()
        val ump = Ump(UmpFactory.midi2NoteOn(0, 0, note, 0, velocity16, 0))
        sendUmpToSlot(0, ump.toPlatformNativeBytes())
    }

    fun sendNoteOff(note: Int, velocity: Float = 0.0f) {
        val velocity16 = (velocity.coerceIn(0.0f, 1.0f) * MIDI2_16BIT_MAX).toInt()
        val ump = Ump(UmpFactory.midi2NoteOff(0, 0, note, 0, velocity16, 0))
        sendUmpToSlot(0, ump.toPlatformNativeBytes())
    }

    fun sendPitchBend(slotIndex: Int = 0, note: Int = -1, value: Float) {
        // UmpFactory.midi2PitchBend expects signed 32-bit: -0x80000000L (-2147483648) to +0x7FFFFFFFL (+2147483647) with 0L at center
        val signed32 = (value.coerceIn(-1.0f, 1.0f).toDouble() * MIDI2_SIGNED_32BIT_MAX.toDouble()).toLong().coerceIn(-MIDI2_SIGNED_32BIT_MAX, MIDI2_SIGNED_32BIT_MAX - 1L)

        val ump = if (note < 0) {
            UmpFactory.midi2PitchBend(0, 0, signed32)
        } else {
            UmpFactory.midi2PerNotePitchBend(0, 0, note, signed32)
        }

        sendUmpToSlot(slotIndex, Ump(ump).toPlatformNativeBytes())
    }

    fun sendPressure(slotIndex: Int = 0, note: Int = -1, value: Float) {
        val pressure32 = (value.coerceIn(0.0f, 1.0f).toDouble() * MIDI2_32BIT_MAX.toDouble()).toLong().coerceIn(0L, MIDI2_32BIT_MAX)

        val ump = if (note < 0) {
            UmpFactory.midi2CAf(0, 0, pressure32)
        } else {
            UmpFactory.midi2PAf(0, 0, note, pressure32)
        }

        sendUmpToSlot(slotIndex, Ump(ump).toPlatformNativeBytes())
    }

    fun sendControlChange(slotIndex: Int = 0, controller: Int, value: Float) {
        val data32 = (value.coerceIn(0.0f, 1.0f).toDouble() * MIDI2_32BIT_MAX.toDouble()).toLong().coerceIn(0L, MIDI2_32BIT_MAX)
        val ump = Ump(UmpFactory.midi2CC(0, 0, controller, data32))
        sendUmpToSlot(slotIndex, ump.toPlatformNativeBytes())
    }

    /** Sends many values (e.g. a session restore) packed into as few UMP inputs as fit. */
    fun setParameterValues(slotIndex: Int, values: List<Pair<ParameterInformation, Double>>) {
        val pending = mutableListOf<Byte>()

        for ((parameter, value) in values) {
            val bytes = parameterChangeBytes(parameter, value)

            if (pending.size + bytes.size > maxUmpInputBytes) {
                sendUmpToSlot(slotIndex, pending.toByteArray())
                pending.clear()
            }

            pending.addAll(bytes.asList())
        }

        if (pending.isNotEmpty()) {
            sendUmpToSlot(slotIndex, pending.toByteArray())
        }
    }

    private fun parameterChangeBytes(parameter: ParameterInformation, value: Double): ByteArray {
        val ints = UmpHelper.aapUmpSysex8ParameterPlain(parameter.id.toUInt(), parameter.minimumValue, parameter.maximumValue, value)
        val umps = ints.filterIndexed { i, _ ->
            i % UMP128_WORD_COUNT == 0
        }.flatMapIndexed { i, v ->
            val start = i * UMP128_WORD_COUNT
            Ump(v, ints[start + 1], ints[start + 2], ints[start + 3]).toPlatformNativeBytes().asList()
        }
        return umps.toByteArray()
    }

    private fun sendUmpToSlot(slotIndex: Int, bytes: ByteArray) {
        if (slotIndex in 0 until numSlots) {
            nativeSendUmp(slotIndex, bytes, bytes.size)
        }
    }

    override fun close() {
        try {
            if (isProcessing) {
                pause()
            }

            nativeShutdown()
        } catch (e: Throwable) {
            Log.e(TAG, "Error closing rack engine", e)
        }
    }
}
